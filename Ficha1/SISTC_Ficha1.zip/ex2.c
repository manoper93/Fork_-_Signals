#include<stdio.h>
#include<unistd.h>

int main(){
	while(1){
		printf("Em funcionamento\n");
		sleep(15);
	}
	return(0);
}
